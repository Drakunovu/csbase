#ifndef __APPVERSION_H__
#define __APPVERSION_H__

//
// This file is generated automatically.
// Don't edit it.
//

// Version defines
#define APP_VERSION "3.14.0.0-dev"
#define APP_VERSION_C 3,14,0,0
#define APP_VERSION_STRD "3.14.0.0"
#define APP_VERSION_FLAGS 0x0L

#define APP_COMMIT_DATE "Dec 26 2024"
#define APP_COMMIT_TIME "08:29:43"

#define APP_COMMIT_SHA ""
#define APP_COMMIT_URL ""

#endif //__APPVERSION_H__
