#ifndef __APPVERSION_H__
#define __APPVERSION_H__

//
// This file is generated automatically.
// Don't edit it.
//

// Version defines
#define APP_VERSION "5.28.0.0-dev"
#define APP_VERSION_C 5,28,0,0
#define APP_VERSION_STRD "5.28.0.0"
#define APP_VERSION_FLAGS 0x0L

#define APP_COMMIT_DATE "Dec 14 2024"
#define APP_COMMIT_TIME "22:22:17"

#define APP_COMMIT_SHA ""
#define APP_COMMIT_URL ""

#endif //__APPVERSION_H__
